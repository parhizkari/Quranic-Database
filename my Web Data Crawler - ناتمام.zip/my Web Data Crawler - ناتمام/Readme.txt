بسم اللٰه الرّحمٰن الرّحیم
Python's Scrapy should be already installed
To start a new project (if intended not to merely modif a previous one) open a terminal anywhere (good to be in  home/desktop) and write:
	scrapy startproject myWebDataCrawler
Modify (or generate for the first time) the spider in   (home/desktop/)myWebDataCrawler/myWebDataCrawler/spiders/YOURSPIDER.py   for your need
Add   FEED_EXPORT_ENCODING = 'utf-8'   to the file "settings.py" in the folder, in order to scrape the content in utf-8
Open a terminal here in    (home/desktop/)myWebDataCrawler/    folder, and write:
	scrapy crawl YOURSPIDER_NAME -o myData.json
the returned data will be saved in   (home/desktop/)myWebDataCrawler/
