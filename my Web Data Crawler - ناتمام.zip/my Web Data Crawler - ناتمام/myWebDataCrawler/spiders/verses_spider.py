import scrapy
import re
from urllib.parse import unquote			# use as e.g. in   string=unquote(string)   for string to be typesetted in utf-8


class VersesSpider(scrapy.Spider):
	name = "verses"		# this name is important to be unique to this spider, as it will be called from the command line in a terminal:    scrapy crawl NAME
	start_urls = [
		'https://wiki.ahlolbait.com/رده:ترجمه_و_تفسیر_آیات_قرآن',
#		'https://wiki.ahlolbait.com/آیه_1_سوره_اخلاص',
#		'http://alvahy.com/',
	]
	
	# first generate the links to the first verse of each Surah to then start from each
	def parse(self, response):
		verses_page_links = [a["href"] for a in response.css('.mw-category-group ul li a') if "آیه_1_سوره_اخلاص" in unquote(a.text.strip())]
		print(verses_page_links[0])
		yield from response.follow_all(verses_page_links, self.parse_verses)
		
	def parse(self, response):
		yield {
			'id':	re.findall(r'\d+', response.css('body').re_first(r'\[([^\]]+)\]')),							# شماره سوره و آیه به صورت [surah,verse]
#			'ShNzl':response.css('body').re_first(r'نزول\<\/span\>\<\/h2\>[\n]*([\s\S]+?)\<h2\>'),				# شأن نزول
#			'Ts':	response.css('div.tabbertab').getall()[9:14],												# contains 5 Tafseers in an array
#			'tags':	response.css('div.tabbertab::attr(title)').getall()[9:14],									# contains th name of the 5 Tafseers
		}
		
#		pagination_links = response.css('li.next a')
#		yield from response.follow_all(pagination_links, self.parse)
